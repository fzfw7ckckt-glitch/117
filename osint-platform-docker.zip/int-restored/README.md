# int-main (відновлено з архіву)

Відновлений проєкт з `int-main.zip` (видалений GitHub repo).

## 57 інструментів OSINT

- GEOINT, SIGINT, SOCMINT, FININT, DARKWEB, CONTACT, AI, TRANSPORT, UKRAINE

## Запуск

```bash
# З кореня osint-platform-2026
docker-compose -f docker-compose.int.yml up -d
```

- **Frontend:** http://localhost:3000
- **API:** http://localhost:8000
- **API Docs:** http://localhost:8000/docs

## Структура

- `backend/` — FastAPI, 57 tools, Celery
- `frontend/` — Next.js 14, MUI, Pages Router
