# 📊 OSINT Platform 2026 - Система Звітності та Аналізу

## 🎯 ФУНКЦІОНАЛЬНІСТЬ "ЗАГАЛЬНИЙ ЗВІТ"

Повноцінна система для генерації комплексних OSINT звітів з експортом у 4 формати:

### 📋 Типи Звітів

| Формат | Тип | Використання | Функції |
|--------|------|-------------|---------|
| **JSON** | Структурований | API, обробка даних | Максимум деталей |
| **HTML** | Веб-сторінка | Рецензенти, презентація | Красиво оформлено |
| **Markdown** | Текст | Документація, Git | Легко редагувати |
| **CSV** | Таблиця | Excel, аналіз | Для даних |

---

## 🔌 API ENDPOINTS ДЛЯ ЗВІТІВ

### 1. Резюме розслідування
```bash
GET /reports/{investigation_id}/summary
```
**Відповідь:**
```json
{
  "investigation": {
    "id": "...",
    "title": "...",
    "target": "...",
    "status": "pending",
    "created_at": "..."
  },
  "evidence_count": 5,
  "tools_used": ["maigret", "shodan"]
}
```

### 2. Генерація ЗАГАЛЬНОГО ЗВІТУ
```bash
POST /reports/{investigation_id}/generate-report?format=json
POST /reports/{investigation_id}/generate-report?format=html
POST /reports/{investigation_id}/generate-report?format=markdown
POST /reports/{investigation_id}/generate-report?format=csv
```

**Параметри:**
- `format` - JSON, HTML, Markdown, CSV
- `include_analysis` - Включити аналіз загроз (за замовч. true)

**Відповідь (JSON):**
```json
{
  "id": "investigation_001",
  "created_at": "2026-03-10T21:32:16.086905",
  "sections": [
    {
      "type": "executive_summary",
      "title": "Виконавчий звіт",
      "data": {
        "target": "john_doe",
        "key_findings": "...",
        "risk_level": "UNKNOWN"
      }
    },
    {
      "type": "threat_assessment",
      "title": "Оцінка загроз і ризиків",
      "data": {
        "threat_count": 3,
        "threats": [...],
        "overall_risk": 0.45
      }
    },
    {
      "type": "recommendations",
      "title": "Рекомендації",
      "data": {
        "recommendations": [...]
      }
    },
    {
      "type": "evidence",
      "title": "Збережені докази",
      "data": {
        "evidence_count": 5,
        "evidence": [...],
        "integrity_verified": true
      }
    },
    {
      "type": "conclusion",
      "title": "Висновки",
      "data": {
        "conclusion": "...",
        "report_finalized": true
      }
    }
  ],
  "metadata": {
    "tools_used": ["maigret", "shodan", "geospy"],
    "evidence_count": 15,
    "confidence_score": 0.85,
    "risk_level": "MEDIUM"
  }
}
```

### 3. Аналіз загроз та ризиків
```bash
GET /reports/{investigation_id}/analysis
```

**Відповідь:**
```json
{
  "investigation_id": "...",
  "threat_assessment": {
    "total_threats": 3,
    "high_severity": 1,
    "threats": [
      {
        "category": "FININT",
        "description": "Виявлені збіги у санкційних списках",
        "severity": "HIGH",
        "count": 1
      }
    ]
  },
  "recommendations": [
    "🔴 НЕГАЙНА: Провести детальну перевірку...",
    "🔵 Зберегти всі докази з хешуванням...",
    "🟢 Налаштувати моніторинг..."
  ],
  "analysis_timestamp": "2026-03-10T21:32:16.263942"
}
```

### 4. Статистика розслідування
```bash
GET /reports/{investigation_id}/statistics
```

**Відповідь:**
```json
{
  "investigation_id": "...",
  "evidence_count": 15,
  "tools_used": {
    "maigret": 3,
    "shodan": 2,
    "geospy": 1
  },
  "categories": {
    "GEOINT": 2,
    "SIGINT": 5,
    "SOCMINT": 8,
    "FININT": 0,
    "DARKWEB": 0,
    "CONTACT": 0,
    "AI": 0,
    "TRANSPORT": 0,
    "OTHER": 0
  },
  "status": "pending",
  "created_at": "2026-03-10T21:23:26.129512",
  "data_quality_score": 95.2
}
```

---

## 🛠️ СИСТЕМА ГЕНЕРАЦІЇ ЗВІТІВ

### Класи

#### 1. **ReportGenerator** - Основний генератор
```python
from app.reporting import ReportGenerator

report = ReportGenerator("investigation_001")

# Додати секції
report.add_executive_summary(target, findings, risk_level)
report.add_osint_search_results(username, results)
report.add_geolocation_data(locations)
report.add_network_intelligence(infrastructure)
report.add_social_analysis(platforms)
report.add_financial_data(financial_info)
report.add_threat_assessment(threats)
report.add_evidence(evidence_list)
report.add_recommendations(recommendations)
report.add_conclusion(conclusion)

# Експортувати
json_report = report.generate_json_report()
html_report = report.generate_html_report()
md_report = report.generate_markdown_report()
csv_report = report.generate_csv_report()
```

#### 2. **AnalysisGenerator** - Аналіз даних
```python
from app.reporting import AnalysisGenerator

# Згенерувати оцінку загроз
threat_assessment = AnalysisGenerator.generate_threat_assessment(data)

# Згенерувати рекомендації
recommendations = AnalysisGenerator.generate_recommendations(analysis)
```

#### 3. **ReportExporter** - Експорт
```python
from app.reporting import ReportExporter, ReportFormat

# Експортувати у різні формати
json_str = ReportExporter.export(report_data, ReportFormat.JSON)
html_str = ReportExporter.export(report_data, ReportFormat.HTML)
md_str = ReportExporter.export(report_data, ReportFormat.MARKDOWN)
csv_str = ReportExporter.export(report_data, ReportFormat.CSV)
```

---

## 📑 СТРУКТУРА ЗВІТУ

### Секції звіту

1. **Executive Summary** (Виконавчий звіт)
   - Основна мета розслідування
   - Ключові знахідки
   - Рівень ризику

2. **OSINT Search Results** (Результати пошуку)
   - Знайдені облікові записи
   - Платформи
   - Посилання на профілі

3. **Geolocation Data** (Геолокаційні дані)
   - Координати
   - Супутникові знімки
   - Карти

4. **Network Intelligence** (Мережева розвідка)
   - Хости та сервери
   - TLS сертифікати
   - Вразливості

5. **Social Analysis** (Аналіз соціальних мереж)
   - Активність
   - Підписники
   - Характер постів

6. **Financial Data** (Фінансові дані)
   - Статус санкцій
   - PEP статус
   - Компанії

7. **Threat Assessment** (Оцінка загроз)
   - Виявлені загрози
   - Рівень ризику
   - Рекомендації зниження

8. **Evidence** (Докази)
   - Всі знайдені докази
   - SHA-256 хеші (юридична значущість)
   - Часові мітки

9. **Recommendations** (Рекомендації)
   - КРИТИЧНО
   - Важливо
   - Рекомендується

10. **Conclusion** (Висновки)
    - Загальні висновки
    - Дата завершення
    - Кількість інструментів

---

## 🎓 ПРИКЛАДИ ВИКОРИСТАННЯ

### Приклад 1: Генерація простого звіту
```bash
curl -s -X POST \
  "http://localhost:8000/reports/investigation_001/generate-report?format=json" \
  | jq '.' > report.json
```

### Приклад 2: Експорт в HTML (для презентації)
```bash
curl -s -X POST \
  "http://localhost:8000/reports/investigation_001/generate-report?format=html" \
  > report.html

# Відкрити в браузері
open report.html
```

### Приклад 3: Експорт в Markdown (для документації)
```bash
curl -s -X POST \
  "http://localhost:8000/reports/investigation_001/generate-report?format=markdown" \
  > report.md

# Завантажити на GitHub
git add report.md
git commit -m "OSINT investigation report"
git push
```

### Приклад 4: Аналіз загроз
```bash
curl -s \
  "http://localhost:8000/reports/investigation_001/analysis" \
  | jq '.threat_assessment'
```

### Приклад 5: Статистика
```bash
curl -s \
  "http://localhost:8000/reports/investigation_001/statistics" \
  | jq '.categories'
```

---

## 🔐 ЮРИДИЧНА ЗНАЧУЩІСТЬ ДОКАЗІВ

Всі докази в звіті містять:

1. **SHA-256 хеш** - Для верифікації цілісності
2. **Часова мітка** - Документування моменту збору
3. **Метадані джерела** - Який інструмент використаний
4. **Підпис цілісності** - Для судового використання

**Приклад:**
```json
{
  "source": "maigret",
  "data": "{\"username\": \"john_doe\", \"platform\": \"twitter\"}",
  "hash_sha256": "a3f9e...d2c1",
  "timestamp": "2026-03-10T21:32:16.000000",
  "integrity_verified": true
}
```

---

## 📊 РІВНІ РИЗИКУ

| Рівень | Код | Опис | Дія |
|--------|------|------|------|
| **CRITICAL** | 🔴 | Вкрай загрозливо | НЕГАЙНА реакція |
| **HIGH** | 🟠 | Дуже загрозливо | Рекомендується |
| **MEDIUM** | 🟡 | Помірна загроза | Розглянути |
| **LOW** | 🟢 | Низька загроза | Моніторинг |
| **UNKNOWN** | ⚪ | Дані відсутні | Дослідження |

---

## 📈 РОЗШИРЕННЯ СИСТЕМИ

### Додання нової категорії аналізу

```python
# У файлі reporting.py
class ReportSectionType(str, Enum):
    MY_CATEGORY = "my_category"

# У класі ReportGenerator
def add_my_section(self, data: Dict) -> None:
    section = {
        "type": ReportSectionType.MY_CATEGORY.value,
        "title": "Моя категорія",
        "data": data
    }
    self.report_data["sections"].append(section)
```

### Додання нового формату експорту

```python
# У ReportGenerator
def generate_pdf_report(self) -> bytes:
    """Експортувати у PDF"""
    # Реалізація з використанням reportlab
    pass

# У ReportExporter
elif format == ReportFormat.PDF:
    return generator.generate_pdf_report()
```

---

## 🚀 ШВИДКИЙ СТАРТ

### 1. Створити розслідування
```bash
TOKEN=$(curl -s -X POST http://localhost:8000/auth/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=user1&password=pass" | jq -r '.access_token')

curl -X POST http://localhost:8000/investigations/ \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test","target_identifier":"john_doe"}'
```

### 2. Отримати ID
```bash
INV_ID="..."
```

### 3. Отримати резюме
```bash
curl http://localhost:8000/reports/$INV_ID/summary
```

### 4. Отримати аналіз
```bash
curl http://localhost:8000/reports/$INV_ID/analysis
```

### 5. Отримати статистику
```bash
curl http://localhost:8000/reports/$INV_ID/statistics
```

### 6. Генерувати повний звіт
```bash
curl -X POST http://localhost:8000/reports/$INV_ID/generate-report?format=html > report.html
```

---

## ✅ ПЕРЕВІРЕНИЙ ФУНКЦІОНАЛ

✅ Генерація звітів у 4 форматах (JSON, HTML, Markdown, CSV)
✅ Аналіз загроз та ризиків
✅ Генерація рекомендацій
✅ Хешування доказів (SHA-256)
✅ Статистика розслідування
✅ Юридична значущість
✅ Все протестовано та розгорнуто

---

**Звітна система повністю готова до використання!** 🎯
